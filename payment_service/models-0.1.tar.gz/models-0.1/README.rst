=====
Models
=====

This is a django project that creates the payments database to be used by other micro-services

Quick start
-----------

1. Add "models" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'models',
    ]

2. Run ``python manage.py migrate`` to create the models.

3. The microservice can now use the database models